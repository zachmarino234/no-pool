===============================================================================
NO POOL PRODUCTIONS - LOGO PACKAGE
===============================================================================

Thank you for using the official No Pool Productions logo assets and making a 
splash with us! This package contains our logos in multiple formats and 
variations. Please review the guidelines below to ensure correct and consistent 
use of our brand.

-------------------------------------------------------------------------------
CONTENTS
-------------------------------------------------------------------------------

FORMATS

  /SVG    - Vector files. Scalable to any size without loss of quality.
            Best for web, digital design, and large-format printing.
            Use these whenever possible.

  /PNG    - Raster files with transparent backgrounds.
            Best for quick placement and tools that don't support SVG.


BACKGROUND VARIATIONS

  White (default) - For use on white or light-colored backgrounds.
  Black           - For use on black or dark-colored backgrounds.
  Blue            - For use on blue/brand-colored backgrounds.


LOGO CONFIGURATIONS

  Wordmark (default) - The full "No Pool Productions" text treatment.
  Logomark           - The icon/symbol on its own.
  Combined           - The logomark and wordmark locked together.


-------------------------------------------------------------------------------
THE DEFAULT LOGO
-------------------------------------------------------------------------------

When in doubt, use the WHITE BACKGROUND WORDMARK in the highest quality
available:

  --> SVG (preferred), or the largest PNG if a raster file is required.

This is the standard, go-to configuration and should be your first choice
unless a specific background or layout calls for another variation.


-------------------------------------------------------------------------------
CHOOSING THE RIGHT FILE
-------------------------------------------------------------------------------

  WEB & DIGITAL ........... SVG when possible; PNG as a fallback.
  PRINT ................... SVG, or the highest-resolution PNG available.
  SOCIAL MEDIA ............ PNG for profile images and posts.
  DOCUMENTS ............... PNG (transparent background).

Always pick the background variation that best matches where the logo will
sit, so it stays legible and high-contrast:

  - White variation  on light backgrounds
  - Black variation  on dark backgrounds
  - Blue variation   on blue/brand backgrounds

Use the wordmark for most general purposes, the combined lockup when you want
both the icon and the name, and the logomark alone in tight spaces such as
favicons, app icons, or social avatars.


-------------------------------------------------------------------------------
BEST PRACTICES
-------------------------------------------------------------------------------

DO:
  - Maintain clear space around the logo on all sides.
  - Scale the logo proportionally to preserve its aspect ratio.
  - Place the logo on backgrounds that provide sufficient contrast.
  - Use the SVG files when scaling for large or high-resolution formats.

DO NOT:
  - Stretch, squash, or distort the logo.
  - Rotate the logo or alter its orientation.
  - Change the logo's colors.
  - Add drop shadows, glows, outlines, or other effects.
  - Recreate, redraw, or modify the logo in any way.
  - Place the logo on a busy or low-contrast background.
  - Crop the logo or remove any of its elements.


-------------------------------------------------------------------------------
MINIMUM SIZE
-------------------------------------------------------------------------------

To preserve legibility, avoid displaying the wordmark or combined logo below
roughly 120px wide on screen (or 1 inch wide in print). The logomark may be
used smaller when the full logo isn't practical.


-------------------------------------------------------------------------------
QUESTIONS & PERMISSIONS
-------------------------------------------------------------------------------

These assets are the property of No Pool Productions. For questions about
usage, requests for additional formats, or permission to use the logo in
ways not covered above, please contact No Pool Productions directly.

===============================================================================
